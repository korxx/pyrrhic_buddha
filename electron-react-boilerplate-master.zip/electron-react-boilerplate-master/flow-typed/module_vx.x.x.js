declare module 'module' {
  declare module.exports: any;
}
