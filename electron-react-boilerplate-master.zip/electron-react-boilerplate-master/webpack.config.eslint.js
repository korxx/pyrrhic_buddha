require('babel-register');

module.exports = require('./webpack.config.renderer.dev');
